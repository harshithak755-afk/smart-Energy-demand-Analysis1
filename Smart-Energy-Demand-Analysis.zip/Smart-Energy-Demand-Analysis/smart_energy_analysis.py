import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load dataset
df = pd.read_csv("smart_energy_data.csv")

print("Data Preview:\n")
print(df.head())

# Total Renewable Production
df["Total_Renewable"] = df["Solar_MW"] + df["Wind_MW"]

# Energy Deficit Calculation
df["Energy_Deficit"] = df["Energy_Demand_MW"] - df["Total_Renewable"]

df["Deficit_Status"] = np.where(df["Energy_Deficit"] > 0,
                                "Shortage",
                                "Surplus")

print("\nEnergy Deficit Analysis:\n")
print(df[["Month", "Energy_Demand_MW", "Total_Renewable", "Energy_Deficit", "Deficit_Status"]])

# Peak Load Detection
peak = df.loc[df["Energy_Demand_MW"].idxmax()]
print("\nPeak Load Month:", peak["Month"])
print("Peak Demand:", peak["Energy_Demand_MW"])

# Plot Demand
plt.figure()
plt.plot(df["Month"], df["Energy_Demand_MW"])
plt.title("Monthly Energy Demand")
plt.xticks(rotation=45)
plt.show()

# Plot Renewable
plt.figure()
plt.plot(df["Month"], df["Total_Renewable"])
plt.title("Total Renewable Production")
plt.xticks(rotation=45)
plt.show()

# Deficit Bar Chart
plt.figure()
sns.barplot(x="Month", y="Energy_Deficit", data=df)
plt.title("Energy Deficit / Surplus")
plt.xticks(rotation=45)
plt.show()

# Correlation Heatmap
plt.figure()
sns.heatmap(df.corr(numeric_only=True), annot=True)
plt.title("Correlation Matrix")
plt.show()

# Optimization Suggestions
print("\nOptimization Suggestions:")
for index, row in df.iterrows():
    if row["Energy_Deficit"] > 100:
        print(f"{row['Month']}: High deficit - Increase solar capacity or battery storage.")
    elif row["Energy_Deficit"] > 0:
        print(f"{row['Month']}: Moderate deficit - Improve wind efficiency.")
    else:
        print(f"{row['Month']}: Surplus - Store excess energy.")