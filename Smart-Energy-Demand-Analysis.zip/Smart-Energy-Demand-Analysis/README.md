# Smart Energy Demand vs Production Analysis

## Objective
Analyze city energy demand vs renewable production.

## Features
- Deficit Detection
- Peak Load Analysis
- Seasonal Trend Analysis
- Optimization Suggestions

## Tools
- Python
- Pandas
- Matplotlib
- Seaborn